RAJÓN — zdrojové kódy aktuálního prototypu

Spuštění:
Rozbal ZIP a otevři index.html v prohlížeči.
Případně otevři složku ve VS Code a použij Live Server.

Soubory:
index.html — struktura aplikace a SVG mapa
style.css — vzhled, Amaranth a mobilní rozhraní
app.js — navigace, popupy, questy, žebříček a odznaky

Font Amaranth se načítá z Google Fonts a vyžaduje internet.
Jde o designový prototyp s fiktivními daty, bez backendu a GPS.
Tým změníš v profilu kliknutím na název týmu.
